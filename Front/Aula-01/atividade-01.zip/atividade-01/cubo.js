let numero = prompt("Qual o valor?");

alert("O cubo de " + numero + " é " + (numero ** 3))