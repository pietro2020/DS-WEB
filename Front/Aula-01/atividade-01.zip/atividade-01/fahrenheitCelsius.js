let fahrenheit = prompt("Qual a temperatura em Fahrenheit?");

const celsius = (fahrenheit - 32) * (5 / 9);

alert(celsius);