let nome = prompt("Qual o seu nome?");
let sobrenome = prompt("Qual o seu sobrenome?");

alert(nome + " " + sobrenome);